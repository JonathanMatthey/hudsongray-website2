var language = new Class({
	
	lang: 'EN',
	panel_name:'Pictures',
	close:'Close',
	add_dir:'Add directory',
	add_picture:'Add photo',
	confirm:'Are you sure?',
	confirmTree:'Are you sure? \n\n Delete all sub-tree',
	search:'Search',
	del:'Delete',
	renew:'Try Again',
	empty_dir:'Empty directory',
	file_error:'Error - file fail',
	serverError:'Error - permission denied',
	serverErrorFile:'Error - can\'t change file name',
	file_doubled:'Error - doubled files',
	add_picture_text:'You can add many files if you press ctrl',
	file_added:'File added',
	send_files:'Send files'
});