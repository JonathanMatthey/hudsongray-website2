var language = new Class({
	
	lang: 'PL',
	panel_name:'Zdjęcia',
	close:'Zamknij',
	add_dir:'Dodaj katalog',
	add_picture:'Dodaj zdjęcie',
	confirm:'Czy jesteś pewien?',
	confirmTree:'Czy jesteś pewien? \n\n Podkatalogi zostaną usunięte',
	search:'Szukaj',
	del:'Usuń',
	renew:'Ponów',
	serverError:'Błąd - nie masz uprawnień do lokalizacji',
	serverErrorFile:'Błąd - nie moge zmienić nazwy pliku',
	empty_dir:'Musisz wskazać katalog docelowy',
	file_error:'Błąd - dodawanie pliku zakończone niepowodzeniem',
	file_doubled:'Błąd - dwa identyczne pliki',
	add_picture_text:'Możesz wgrać wiele zdjęc przytrzymując ctrl',
	file_added:'Plik został dodany',
	send_files:'Wyślij pliki'
});